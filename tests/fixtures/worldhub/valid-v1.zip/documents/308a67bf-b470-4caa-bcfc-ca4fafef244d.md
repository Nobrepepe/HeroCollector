# The Emberfall Accord

The city agreed to feed the star one memory a year.